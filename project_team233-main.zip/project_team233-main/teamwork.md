Teamwork Agreement Responses:
- Communication: Discord & iMessage - Expectation is to respond within 24 hours at latest.
- Meeting Times: Hybrid meetings, usually online with the occasional physical get together
- Work Style: Start tasks early, but gradually get to the completion roughly being done before 1-3 days before the due date.
- Weekly Meetings?: No weekly meetings, just constant messaging back and forth and updates
- Frequency of Push & Pull: Pushing work to GitHub when a substantial amount of work is done, potentially a method or pushing when an issue arises and the other person needs to take a look at the code. There isn't that big of a strict guideline we should follow. Pulls should be asap.
- Hard Deadlines: Hard deadlines are just to consistently work and make sure we are done before 1-3 days before the submission time. We only have 3 autotest's a day so using as many days and being as consistent is best.
- Etc.: Constant communication will be key.
